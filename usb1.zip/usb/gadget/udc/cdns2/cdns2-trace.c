// SPDX-License-Identifier: GPL-2.0
/*
 * USBHS device controller driver Trace Support
 *
 * Copyright (C) 2023 Cadence.
 *
 * Author: Pawel Laszczak <pawell@cadence.com>
 */

#define CREATE_TRACE_POINTS
#include "cdns2-trace.h"
